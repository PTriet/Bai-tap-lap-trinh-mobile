package com.example.thuchanh1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() { //componentActivity(): dùng để chạy Compose UI
    override fun onCreate(savedInstanceState: Bundle?) { //onCreate: nơi app khởi tạo lần đầu
        super.onCreate(savedInstanceState)
        setContent { //dựng UI bằng Compose
             MaterialTheme { //nền
                Surface( //khung bố cục
                    modifier = Modifier.fillMaxSize(),//chiều rộng, cao chiếm 100% màn hình
                    color = MaterialTheme.colorScheme.background//dùng nền mặc định
                ) {
                    AgeCheckerScreen() //hàm hiển thị giao diện chính
                }
            }
        }
    }
}

@Composable // hàm UI, vẽ giao diện lên màn hình
fun AgeCheckerScreen() {
    var name by remember { mutableStateOf(TextFieldValue("")) } //remember lưu trạng thái UI, mutable...: tạo một biến có thể cập nhật UI khi giá trị thay đổi
    var ageText by remember { mutableStateOf(TextFieldValue("")) }
    var result by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .padding(24.dp)//lề xung quanh 24dp
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)//cách đều các phần tử 16dp
    ) {
        Text(text = "THỰC HÀNH 01", style = MaterialTheme.typography.headlineMedium)//MaterialTheme.typography.+...:dùng để định dạng chữ như h1, h2 trong HTML

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },//để khi nhập chữ thì Compose có thể cập nhật và hiển thị chữ
            label = { Text("Họ và tên") },
            modifier = Modifier.fillMaxWidth()//modifier: thiết lập kích thước, vị trí
        )

        OutlinedTextField(
            value = ageText,
            onValueChange = { ageText = it },
            label = { Text("Tuổi") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true //vì là true nên ng dùng không thể xuống dòng bằng phím Enter và gõ hết chiều rộng sẽ cuộn ngang
        )

        Button(
            onClick = {
                val age = ageText.text.toIntOrNull()//toIntOrNull():tránh lỗi app bị crash khi nhập chữ
                result = if (age == null || name.text.isBlank()) {
                    "Vui lòng nhập đầy đủ và đúng thông tin!"
                } else {
                    val category = when {
                        age > 65 -> "Người già"
                        age in 6..65 -> "Người lớn"
                        age in 2..5 -> "Trẻ em"
                        else -> "Em bé"
                    }
                    "${name.text} thuộc nhóm: $category"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Kiểm tra")
        }

        if (result.isNotBlank()) {
            Text(
                text = result,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}
